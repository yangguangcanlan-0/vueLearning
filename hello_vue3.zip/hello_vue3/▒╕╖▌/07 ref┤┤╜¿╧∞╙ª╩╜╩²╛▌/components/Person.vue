<template>
    <div class="person">
        <h2>姓名：{{ name }}</h2>
        <h2>年龄：{{ age }}</h2>
        <button @click="showTel">查看联系方式</button>
        <button @click="changeAge">年龄+1</button>
        <button @click="changeName">修改名字</button>
    </div>
</template>

<script setup lang="ts" name='Person'>
    import {ref} from 'vue'
    let name = ref('张三')
    let age = ref(18)
    let tel = '17328872479'
    function showTel() {
        alert(tel)
    }
    function changeAge() {
        age.value += 1
        console.log(age.value)
    }
    function changeName() {
        name.value = 'zhangsan'
        console.log(name.value)
    }
</script>

<style scoped>
.person {
    background-color: skyblue;
    box-shadow: 0 0 10px;
    border-radius: 10px;
    padding: 20px;
}

button {
    margin: 0, 5px;
}
</style>