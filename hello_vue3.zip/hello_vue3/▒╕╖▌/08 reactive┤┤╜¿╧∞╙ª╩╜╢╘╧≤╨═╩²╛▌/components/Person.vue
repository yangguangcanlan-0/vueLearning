<template>
    <div class="person">
        <h2>汽车信息：一台{{ car.brand }}汽车, 价值{{ car.price }}万</h2>
        <h2>游戏列表：</h2>
        <ul>
            <li v-for="g in games" v-bind:key="g.id">{{ g.name }}</li>
        </ul>
        <h2>测试：{{obj.a.b.c.d}}</h2>
        <button @click="changeCarPrice">修改汽车价格</button>
        <button @click="changeFistName">修改第一游戏</button>
        <button @click="test">测试</button>
    </div>
</template>

<script setup lang="ts" name='Person'>
    import {ref} from 'vue'
    import {reactive} from 'vue'
    let car = reactive({brand: '奔驰', price:100})
    let games = reactive([
        {id:'agagagag01', name:'英雄联盟'},
        {id:'agagagag02', name:'无畏契约'},
        {id:'agagagag03', name:'王者荣耀'}
    ])
    let obj = reactive({
        a:{
            b:{
                c:{
                    d:666
                }
            }
        }
    })
    function changeCarPrice(){
        car.price+=10
    }
    function changeFistName(){
        games[0].name='和平精英'
    }
    function test(){
        obj.a.b.c.d=999
    }
</script>

<style scoped>
.person {
    background-color: skyblue;
    box-shadow: 0 0 10px;
    border-radius: 10px;
    padding: 20px;
}

button {
    margin: 0 5px;
}
</style>