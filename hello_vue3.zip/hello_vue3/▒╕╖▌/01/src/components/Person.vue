<template>
    <div class="person">
        <h2>姓名：{{ name }}</h2>
        <h2>年龄：{{ age }}</h2>
        <button @click="showTel">查看联系方式</button>
        <button @click="changeAge">年龄+1</button>
        <button @click="changeName">修改名字</button>
    </div>
</template>

<script lang="ts">

export default {
    name:'Person',
    setup(){
        let name='张三'
        let age = 18
        let tel = '17328872479'
        function showTel(){
            alert(tel)
        }
        function changeAge(){
            age+=1
            console.log(age)
        }
        function changeName(){
            name = 'zhangsan'
            console.log(name)
        }
        return {name, age, tel, showTel, changeName, changeAge}
    },
    }

</script>

<style scoped>
    .person {
        background-color:skyblue;
        box-shadow: 0 0 10px;
        border-radius: 10px;
        padding: 20px;
    }
    button {
        margin: 0, 5px;
    }
</style>