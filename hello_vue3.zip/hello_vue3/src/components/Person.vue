<template>
    <div class="person">
        <h2>姓名：{{ person.name }}</h2>
        <h2>年龄：{{ person.age }}</h2>
        <h2>性别：{{ person.gender }}</h2>
        <button @click="changeName">修改名字</button>
        <button @click="changeAge">修改年龄</button>
        <button @click="changeGender">修改性别</button>
    </div>
</template>

<script setup lang="ts" name='Person'>
    import {reactive, ref, toRefs, toRef} from 'vue'
    let person = reactive({
        name:'张三',
        age:18,
        gender:'男'
    })
    let {name, gender} = toRefs(person)
    let age = toRef(person,'age')

    function changeName(){
        name.value+='~'
        console.log(name.value, person.name)
    }
    function changeAge(){
        age.value+=1
        console.log(age.value, person.age)
    }
    function changeGender(){
        gender.value = '女'
    }

    
    

</script>

<style scoped>
.person {
    background-color: skyblue;
    box-shadow: 0 0 10px;
    border-radius: 10px;
    padding: 20px;
}

button {
    margin: 0 5px;
}
</style>